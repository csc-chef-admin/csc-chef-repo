## 2.0.0
* Add travis.yml file to run Rubocop and Foodcritic
* Update Rubocop rules
* Fix Rubocop warnings
* Added a Gemfile
* Added a Berksfile
* Added gitignore file
* Added chefignore file
* Renamed defaults.rb attribute file to default.rb [juliandunn]
* Update to version of .NET to be installed to 4.5.2 [juliandunn]


For previous changes see the git log

