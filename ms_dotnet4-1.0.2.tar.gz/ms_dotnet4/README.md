Description
===========

This cookbook installs the Microsoft .NET Framework 4.0

Requirements
============

* Windows cookbook

Platform
--------

*Windows Vista SP1 or later
*Windows Server 2008 (not supported on Server Core Role)
*Windows 7
*Windows Server 2008 R2 (not supported on Server Core Role)


Attributes
==========

Usage
=====

Include the default recipe on a node's runlist to ensure that .NET Framework 4.0 is installed on the system

